﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.Work_force.Contracts
{
    public interface IWriter
    {
        void WriteLine(string text);
    }
}
